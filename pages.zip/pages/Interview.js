import React from 'react'
import InterCard from './Component/InterCard'

const Interview = () => {
  return (
    <>
      <section className="text-gray-600 body-font container" style={{"paddingRight":"3em","paddingTop":"1em","paddingLeft":"3em", "height":"50vh", "background":"#dad5d53d"}}>
        <div className="container  py-3 mx-auto">
          <div className="flex flex-col text-center w-full mb-6">
          <h1 className='font-bold text-start' style={{ 'fontSize': "30px", "lineHeight":"6px" }}>Views / Reviews / Interviews</h1>
          </div>
          <div className="flex flex-wrap -m-4">
            <InterCard />
          </div>
        </div>
      </section>
    </>
  )
}

export default Interview