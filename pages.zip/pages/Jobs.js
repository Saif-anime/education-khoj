import React from 'react';
import JobComp from './Component/JobComp';

const Jobs = () => {
  return (
    <>
    <div className="container mt-60">
    <JobComp/>
    </div>
    </>
  )
}

export default Jobs