import React from 'react'
import Ads from './Component/Ads';
import Search from './Component/Search';
import InterCard from './Component/InterCard';
import News from './News';
import JobComp from './Component/JobComp'
import Link from 'next/link'

const index = () => {

  const search_box = {
    "background": "white",
    "padding": "26px 34px",
    "position": "relative",
    "top": "-6em",
    "border-radius": "5px",
    "box-shadow": "rgb(0 0 0 / 24%) 0px 3px 8px"
  }
  return (
    <>
      <div className="container">
        <Ads />
        {/* banner section is here  */}
        <section className='container' style={{"height":"80vh"}}>
          <div >
            <img style={{"width":"100%", "height":"70vh"}} src="image/banner.jpg" alt="banner" />
          </div>
          <div className="w-4/5 mx-auto mt-4 " style={search_box}>
            <h1 className="sm:text-3xl text-2xl font-medium title-font mb-4 text-center text-gray-900">Search Here</h1>
            <Search />
          </div>
        </section>
        <News />
        <section className="text-gray-600 body-font container" style={{"paddingRight":"3em","paddingTop":"1em", "position":"relative", "top":"-12em","paddingLeft":"3em", "height":"50vh", "background":"#dad5d53d"}}>
        <div className="container  py-3 mx-auto">
          <div className="flex flex-col text-center w-full mb-6">
          <h1 className='font-bold text-start' style={{ 'fontSize': "30px", "lineHeight":"6px" }}>Views / Reviews / Interviews</h1>
          </div>
          <div className="flex flex-wrap -m-4">
            <InterCard />
          </div>
        </div>
      </section>
        <JobComp/>
      </div>
    </>

  )
}

export default index;