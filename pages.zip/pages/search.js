import React from 'react'

const search = () => {
  return (
    <>
    <div className="container">
    <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2 text-center text-gray-900">Search Here</h1>
    </div>
    </>
  )
}

export default search