import React from 'react'
import { useRouter } from 'next/router';
const Form = () => {
    const router = useRouter()
    let path = router.asPath


    return (
        <>
         
        </>
    )
}

export default Form