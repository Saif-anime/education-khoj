import React from 'react'

const Jobcard = ({cata, jobrole}) => {
  return (
    <>
      <div class="py-1 flex flex-wrap md:flex-nowrap">
        <div class="md:flex-grow">
          <h2 class="text-2xl font-medium text-gray-900 title-font mb-2">{jobrole}</h2>
          <span class="mt-1 text-gray-500 text-sm">12 Jun 2019</span>
          <p class="leading-relaxed" style={{"lineHeight":"1.5em"}}>Glossier echo park pug, church-key sartorial biodiesel vexillologist pop-up snackwave ramps cornhole. Marfa 3 wolf moon party messenger bag selfies, poke vaporware kombucha lumbersexual pork belly polaroid hoodie portland craft beer.</p>
          <a class="text-indigo-500 cursor-pointer inline-flex items-center mt-4">Know More
            <svg class="w-4 h-4 ml-2" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14"></path>
              <path d="M12 5l7 7-7 7"></path>
            </svg>
          </a>
          <button class="text-white bg-indigo-500 border-0 py-1 px-3 focus:outline-none hover:bg-indigo-600 cursor-pointer rounded text-lg" style={{"marginLeft": "48em", "padding":"1px 9px", "fontSize": "0.9em"}}>Apply Now</button>
        </div>
      </div>
    </>
  )
}

export default Jobcard;