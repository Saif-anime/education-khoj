import React from 'react'
import Jobcard from './Jobcard'

const JobComp = () => {
  return (
    <>
      <section className="text-gray-600 body-font container px-6 py-2" style={{"position": "relative","top": "-12em"}}>
        <div className='grid grid-cols-3 gap-4'>
          <div className='w-full col-span-2 bg-gray-50 px-6 py-2'>
            <h2 className='text-gray-800 text-3xl font-bold'>Hot Jobs</h2>
            {/* card job is here  */}
            <section class="text-gray-600 body-font overflow-hidden">
              <div class="container px-5 py-8 mx-auto">
                <div class="-my-8 divide-y-2 divide-gray-100">
               <Jobcard jobrole = "Frontend Devlopment Trainer"/>
               <Jobcard jobrole = "Math Teacher"/>
               <Jobcard jobrole = "Science Teacher"/>
               <Jobcard jobrole = "Computer Teacher"/>
               <Jobcard jobrole = "Frontend Devlopment Trainer"/>
                </div>
              </div>
            </section>
          </div>
          <div className='w-full bg-gray-50 px-6 py-2'>
            <p className='text-grey-200 text-xl'>Recruitment agencies</p>
            <h1 className='text-gray-800 text-3xl font-bold'>Top Recruitments</h1>
          </div>

          </div>
      </section>
    </>
  )
}

export default JobComp