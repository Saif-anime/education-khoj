import React from 'react'

const Ads = () => {
  
  return (
    <>
    <div>
        <form>
            <div className='border-2' style={{"width":"970px", "height":"90px","margin": "auto",}}>
                <img src="image/Adsbanner.png" className="object-fill w-full h-full" alt="Ads" />
            </div>
        </form>
    </div>
    </>
  )
}

export default Ads