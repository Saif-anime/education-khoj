import { redirect } from "next/dist/server/api-utils";
import conn from "../../middleware/conn";
import User from "../../Modals/user";


const handler = async(req, res)=> {
    try {
        if(req.method == "POST"){
            const {name, email, pass, cpass} = req.body; 
            if(pass == cpass){
                const user = new User({
                    name,
                    email,
                    pass
                })
                const usersave = await user.save();
                if(usersave){
                    // res.status(201).send('you are succ !')
                    return NextResponse.redirect('/Sign')
                    // res.status(201).json({User});
                }else{
                    res.status(401).send('you are not succ !')
                }
            }
        }else{
            console.log(e);
        }
        } catch (e) {
            res.status(401).send(e);
    }
  }

  export default conn(handler);