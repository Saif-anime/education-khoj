import conn from "../../middleware/conn";
import News from "../../Modals/news";
import multer from "multer";



// Returns a Multer instance that provides several methods for generating 
// middleware that process files uploaded in multipart/form-data format.
//Configuration for Multer

const upload = multer({
    storage: multer.diskStorage({
      destination: './public/uploads',
      filename: (req, file, cb) => cb(null, file.originalname),
    }),
  });


let uploadFile = upload.single('img');


const handler = async(req, res)=> {
    try {
    if(req.method == "POST"){

        const {img} = req.file;

    
            const {title, author, description, catagory, tags} = req.body; 
            
                const news = new News({
                    title, img:img,  author, description, catagory, tags
                })

                // res.send(uploadFile);
                const newsave = await news.save();
                if(newsave){
                    res.status(201).send('you are succ !')
                    res.status(201).json({News});
                }else{
                    res.status(401).send('you are not succ !')
                }
            }
        }catch (e) {
            res.status(401).send(e);
    }
        
  }


// conn();
  export default conn(handler);