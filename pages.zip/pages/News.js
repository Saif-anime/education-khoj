import React from 'react'
import NewsCard from './Component/NewsCard'
const News = () => {
  return (
    <>
      {/* <section className="text-gray-600 body-font container">
        <div className="container px-5 py-12 mx-auto">
          <div className="flex flex-col text-center w-full mb-20">
            <h1 className="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900">News Section </h1>
            <p className="lg:w-2/3 mx-auto leading-relaxed text-base">Whatever cardigan tote bag tumblr hexagon brooklyn asymmetrical gentrify, subway tile poke farm-to-table. Franzen you probably haven't heard of them.</p>
          </div>
            <div className='inline-block w-2/3'>
              <img alt="gallery" class="w-full object-cover h-full object-center block" src="https://dummyimage.com/820x340"/>
            </div>
          <div className="flex flex-wrap -m-2 w-2/3">
            <NewsCard />
            <NewsCard />
            <NewsCard />
            <NewsCard />
            <NewsCard />
            <NewsCard />
            <NewsCard />
            <NewsCard />
          </div>
        </div>
      </section> */}
      <div className="grid-cols-3 cursor-pointer">

        <div class="max-w-screen-lg col-span-2 container px-8" style={{ "display": "inline-block", "position":"relative", "top":"-12em" }}>
          <h1 className='font-bold text-start' style={{ 'fontSize': "30px", "lineHeight":"6px" }}>Latest News </h1>

          <main class="pt-6">
            {/* <!-- featured section --> */}
            <div class="flex md:flex-no-wrap" >
              {/* <!-- main post --> */}
              <div class="mb-4 lg:mb-0  p-4 lg:p-0 w-full md:w-4/7 relative rounded block" style={{ "marginRight": "1em", "width": "85vw" }}>
                <img src="https://images.unsplash.com/photo-1427751840561-9852520f8ce8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="rounded-md object-cover w-full h-64" />
                <span class="text-blue-700 text-sm hidden md:block mt-4"> Technology </span>
                <h1 class="text-gray-800 text-2xl font-bold mt-2 mb-2 leading-tight">
                  Ignorant branched humanity led now marianne too.
                </h1>
                <p class="text-gray-600 mb-4">
                  Necessary ye contented newspaper zealously breakfast he prevailed. Melancholy middletons yet understood
                  Piqued ye of am spirit regret. Stimulated discretion impossible admiration in particular conviction up.
                </p>
              </div>

              {/* <!-- sub-main posts --> */}
              <div class="w-full" style={{ "position": "relative", "right": "-20px" }}>
                {/* <!-- post 1 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10 " style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>

                {/* <!-- post 2 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10" style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>
                {/* <!-- post 3 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10" style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>
                {/* <!-- post 4 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10" style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>

              </div>
              <div class="w-full" style={{ "position": "relative", "right": "-54px" }}>
                {/* <!-- post 1 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10 " style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>

                {/* <!-- post 2 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10" style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>
                {/* <!-- post 3 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10" style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                  </div>
                </div>
                {/* <!-- post 4 --> */}
                <div class="rounded flex flex-col md:flex-row mb-10" style={{ "width": "8vw", "height": "11vh" }}>
                  <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=900&q=60" class="block md:hidden lg:block rounded-md h-64 md:h-32 m-4 md:m-0" style={{ "width": "100%", "height": "100%" }} />
                  <div class="bg-white rounded px-4" style={{ "width": "13vw", "fontSize": "1em" }}>
                    <span class="text-blue-700 text-sm hidden md:block"> Gadgets </span>
                    <div class="md:mt-0 text-gray-800 font-semibold text-xl mb-2" style={{ "fontSize": "1em", "width": "11vw", "height": "100%", "lineHeight": "1.3em" }}>
                      At every tiled on ye defer do. No attention suspected oh difficult.
                    </div>
                    <p class="block md:hidden p-2 pl-0 pt-1 text-sm text-gray-600">
                      Wonder matter now can estate esteem assure fat roused. Am performed on existence as discourse is. Pleasure friendly at marriage blessing or
                    </p>
                    <a href="./blog.html" class="inline-block px-3 py-2 mt-2 rounded-md bg-blue-700 text-gray-100" style={{"position": "relative","right": "-40px","top":"-18px"}}>
                      Read more
                    </a>
                  </div>
                </div>

              </div>

            </div>

          </main>
          {/* <!-- main ends here --> */}
        </div>
        <div className='col-span-2' style={{ "display": "inline-block", "position": "relative", "top": "0em", "right": "-100px" }}>
          <div className="my-4">
            <img src="https://images.creatopy.com/public/templates/gallery/img/bh3070sfk/Upgrade-Your-Career-with-University-Education.jpg" alt="" />
          </div>
          <div>
            {/* 570X90 */}
            <img src="https://images.creatopy.com/public/templates/gallery/img/bztk5zdrq/Lifetime-of-Learning-University-Education.jpg" alt="" />
          </div>

          {/* <div style={{ "display": "inline-block", "width": "300px", "height": "150px", "flexDirection": "column", "justifyContent": "center", "padding": "15px" }}>
            <form action="" method="post">
              <input type="email" className='w-full' style={{
                "border": "2px solid black", "borderRadius": "4px", "marginBottom": "22px",
                "marginTop": "18px"
              }} />
              <button class="text-white w-full bg-indigo-500 border-0 py-1 px-3 focus:outline-none hover:bg-indigo-600 cursor-pointer rounded text-lg">Subscribe Newsletter </button>
            </form>
          </div> */}
        </div>
      </div>
    </>
  )
}

export default News