import React from 'react'
import theme from "../../src/theme/theme";
import FullLayout from "../../src/layouts/FullLayout";
import { ThemeProvider } from "@mui/material/styles";
import {
  Grid,
  Stack,
  TextField,
  Button,
} from "@mui/material";
import BaseCard from "../../src/components/baseCard/BaseCard";
const allinterviews = () => {
  return (
    <>
      <ThemeProvider theme={theme}>
        <FullLayout>
          <style jsx global>{`
        header{
            display:none;
        }
        footer{
            display:none;
        }
      `}</style>

          <Grid container spacing={0}>
            <Grid item xs={12} lg={12}>
              <BaseCard title="Form Layout">
                <Stack spacing={3}>
                  <TextField
                    id="name-basic"
                    label="News Heading"
                    variant="outlined"
                  />
                  <TextField
                    id="name-basic"
                    label="News Category"
                    variant="outlined"
                  />
                  <TextField
                    id="name-basic"
                    label="Which City News"
                    variant="outlined"
                  />


                  <TextField
                    id="outlined-multiline-static"
                    label="News Text"
                    multiline
                    rows={4}
                  />
                  <Button variant="contained" component="label">
                    Upload
                    <input hidden accept="image/*" multiple type="file" />
                  </Button>
                </Stack>
                <br />
                <Button variant="contained" style={{ "background": "red" }} mt={2}>
                  Submit
                </Button>
              </BaseCard>
            </Grid>
          </Grid>
        </FullLayout>
      </ThemeProvider>


    </>
  )
}

export default allinterviews