import React from 'react'
import theme from "../../src/theme/theme";
import FullLayout from "../../src/layouts/FullLayout";
import { ThemeProvider } from "@mui/material/styles";
import {
  Grid,
  Stack,
  TextField,
  Button,
} from "@mui/material";
import BaseCard from "../../src/components/baseCard/BaseCard";

const allnews = () => {
  return (
    <>

      <ThemeProvider theme={theme}>
        <FullLayout>
          <style jsx global>{`
        header{
            display:none;
        }
        footer{
            display:none;
        }
      `}</style>

          <Grid container spacing={0}>
            <Grid item xs={12} lg={12}>
              <form action="/api/Newset" method='post' enctype="multipart/form-data">
                <BaseCard title="Form Layout">
                  <Stack spacing={3}>
                    <TextField
                      id="name-basic"
                      type="text"
                      label="News Heading"
                      name = "title"
                      variant="outlined"
                    />
                    <TextField
                      id="name-basic"
                      type="text"
                      label="Author's Name"
                      name = "author"
                      variant="outlined"
                    />
                    <TextField
                      id="name-basic"
                      type="text"
                      name = "tags"
                      label="Tag"
                      variant="outlined"
                    />
                    <TextField
                      id="name-basic"
                      type="text"
                      label="News Category"
                      name = "catagory"
                      variant="outlined"
                    />
                    {/* <TextField
                      id="name-basic"
                      label="Which City News"
                      name = "city_news"
                      variant="outlined"
                    /> */}


                    <TextField
                      id="outlined-multiline-static"
                      label="News Text"
                      type="text"
                      name = "description"
                      multiline
                      rows={4}
                    />
                    <Button variant="contained" component="label">
                      Upload
                      <input name='img' hidden accept="image/*" multiple type="file" />
                    </Button>
                  </Stack>
                  <br />
                  <Button type='submit' variant="contained" style={{ "background": "red" }} mt={2}>
                    Submit
                  </Button>

                </BaseCard>
              </form>
            </Grid>
          </Grid>
        </FullLayout>
      </ThemeProvider>


    </>
  )
}

export default allnews