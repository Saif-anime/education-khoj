import React from 'react'
import theme from "../../src/theme/theme";
import FullLayout from "../../src/layouts/FullLayout";
import { ThemeProvider } from "@mui/material/styles";

const allbanners = () => {
  return (
    <>
      <ThemeProvider theme={theme}>
        <FullLayout>
          <style jsx global>{`
        header{
            display:none;
        }
        footer{
            display:none;
        }
      `}</style>

          allbanners
        </FullLayout>
      </ThemeProvider>

    </>
  )
}

export default allbanners