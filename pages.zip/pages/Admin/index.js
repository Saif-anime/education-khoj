import React from 'react'
import { Grid } from "@mui/material";
// import SalesOverview from "../../src/components/dashboard/SalesOverview";
// import DailyActivity from "../../src/components/dashboard/DailyActivity";
import ProductPerfomance from "../../src/components/dashboard/ProductPerfomance";
import theme from "../../src/theme/theme";
import FullLayout from "../../src/layouts/FullLayout";
import { ThemeProvider } from "@mui/material/styles";
const index = () => {
  return (
    <>
    <style jsx global>{`
        header{
            display:none;
        }
        footer{
            display:none;
        }
      `}</style>
      <ThemeProvider theme={theme}>
        <FullLayout>
          <Grid container spacing={0}>
            <Grid item xs={12} lg={12}>
            <ProductPerfomance />
            </Grid>
            {/* ------------------------- row 1 ------------------------- */}
            <Grid item xs={12} lg={4}>
           
            </Grid>
            <Grid item xs={12} lg={8}>
           
            </Grid>
            <Grid item xs={12} lg={12}>
          
            </Grid>
          </Grid>
        </FullLayout>
      </ThemeProvider>
    </>
  )
}

export default index