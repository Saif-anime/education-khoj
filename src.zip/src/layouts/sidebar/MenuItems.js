const Menuitems = [
  {
    title: "Dashbaord",
    icon: "home",
    href: "/Admin",
  },
  {
    title: "News Page",
    icon: "disc",
    href: "/Admin/allnews",
  },
  {
    title: "Interview",
    icon: "layout",
    href: "/Admin/allinterviews",
  },
  {
    title: "Job",
    icon: "info",
    href: "/Admin/alljobs",
  },
  {
    title: "Ratings",
    icon: "star",
    href: "/rating",
  },
  {
    title: "Images",
    icon: "image",
    href: "/image",
  },
  {
    title: "Pagination",
    icon: "user",
    href: "/pagination",
  },
  {
    title: "Tables",
    icon: "grid",
    href: "/table",
  },
];

export default Menuitems;
